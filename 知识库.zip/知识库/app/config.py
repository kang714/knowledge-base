"""配置加载模块

从 config.yaml 读取配置，使用 dataclass 提供类型安全的访问。
未在 YAML 中声明的字段使用默认值。
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional
import yaml


@dataclass
class LLMConfig:
    provider: str = "ollama"
    model: str = "qwen2.5:latest"
    temperature: float = 0.7
    max_tokens: int = 2048
    base_url: str = "http://localhost:11434"


@dataclass
class EmbeddingConfig:
    provider: str = "ollama"
    model: str = "nomic-embed-text"
    fallback_model: str = "all-MiniLM-L6-v2"


@dataclass
class ChunkingConfig:
    chunk_size: int = 1000
    chunk_overlap: int = 200


@dataclass
class VectorStoreConfig:
    persist_directory: str = "data/chroma"
    collection_name: str = "knowledge_base"


@dataclass
class AppConfig:
    data_dir: str = "data"
    supported_file_types: List[str] = field(default_factory=lambda: ["txt", "md", "pdf", "docx"])
    max_file_size_mb: int = 50
    search_default_top_k: int = 10
    qa_default_top_k: int = 5


@dataclass
class Config:
    llm: LLMConfig = field(default_factory=LLMConfig)
    embeddings: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)
    app: AppConfig = field(default_factory=AppConfig)


def _dict_to_dataclass(dc_class, data: dict):
    """递归地将 dict 转换为 dataclass 实例。"""
    if data is None:
        return dc_class()
    field_types = {f.name: f.type for f in dc_class.__dataclass_fields__.values()}
    kwargs = {}
    for key, value in data.items():
        if key in field_types:
            if hasattr(field_types[key], "__dataclass_fields__"):
                kwargs[key] = _dict_to_dataclass(field_types[key], value)
            else:
                kwargs[key] = value
    return dc_class(**kwargs)


def load_config(config_path: str = "config.yaml") -> Config:
    """加载配置：YAML 文件值覆盖 dataclass 默认值。

    Args:
        config_path: config.yaml 的路径

    Returns:
        Config 对象
    """
    config = Config()

    # 如果 YAML 文件存在，读取并合并
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            yaml_data = yaml.safe_load(f) or {}

        if "llm" in yaml_data:
            config.llm = _dict_to_dataclass(LLMConfig, yaml_data["llm"])
        if "embeddings" in yaml_data:
            config.embeddings = _dict_to_dataclass(EmbeddingConfig, yaml_data["embeddings"])
        if "chunking" in yaml_data:
            config.chunking = _dict_to_dataclass(ChunkingConfig, yaml_data["chunking"])
        if "vector_store" in yaml_data:
            config.vector_store = _dict_to_dataclass(VectorStoreConfig, yaml_data["vector_store"])
        if "app" in yaml_data:
            config.app = _dict_to_dataclass(AppConfig, yaml_data["app"])

    return config


def save_config(config: Config, config_path: str = "config.yaml") -> None:
    """将配置保存为 YAML 文件（仅保存与默认值不同的字段）。

    Args:
        config: Config 对象
        config_path: 保存路径
    """
    import dataclasses
    data = {
        "llm": dataclasses.asdict(config.llm),
        "embeddings": dataclasses.asdict(config.embeddings),
        "chunking": dataclasses.asdict(config.chunking),
        "vector_store": dataclasses.asdict(config.vector_store),
        "app": dataclasses.asdict(config.app),
    }
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
