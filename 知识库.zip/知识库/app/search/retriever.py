"""ChromaDB 向量检索封装

管理向量存储的增删查操作。
"""

import uuid
from typing import List, Dict, Optional, Callable
import chromadb
from chromadb.config import Settings


class ChromaRetriever:
    """ChromaDB 客户端封装。

    提供向量的存储、相似度搜索和删除功能。
    """

    def __init__(
        self,
        persist_directory: str,
        collection_name: str,
        embedding_fn: Callable[[str], List[float]],
    ):
        """初始化 ChromaDB 检索器。

        Args:
            persist_directory: 持久化目录
            collection_name: 集合名称
            embedding_fn: 文本转向量的函数
        """
        self.persist_directory = persist_directory
        self.collection_name = collection_name
        self.embedding_fn = embedding_fn

        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )

    def add_chunks(
        self,
        chunks: List[str],
        embeddings: List[List[float]],
        doc_id: str,
        filename: str,
    ) -> List[str]:
        """将一个文档的所有分块添加到向量库。

        Args:
            chunks: 文本块列表
            embeddings: 对应的向量列表
            doc_id: 文档 ID
            filename: 文件名（用于元数据）

        Returns:
            ChromaDB 条目 ID 列表
        """
        if not chunks:
            return []

        chroma_ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
        metadatas = [
            {"document_id": doc_id, "chunk_index": i, "filename": filename}
            for i in range(len(chunks))
        ]

        self.collection.add(
            ids=chroma_ids,
            embeddings=embeddings,
            documents=chunks,
            metadatas=metadatas,
        )
        return chroma_ids

    def similarity_search(
        self,
        query: str,
        top_k: int = 10,
        filter_doc_ids: Optional[List[str]] = None,
    ) -> List[Dict]:
        """相似度搜索。

        Args:
            query: 查询文本
            top_k: 返回结果数量
            filter_doc_ids: 限定搜索范围（可选）

        Returns:
            结果列表，每项包含: chroma_id, document_id, content, score, filename, chunk_index
        """
        if self.collection.count() == 0:
            return []

        query_embedding = self.embedding_fn(query)

        where_filter = None
        if filter_doc_ids:
            where_filter = {"document_id": {"$in": filter_doc_ids}}

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )

        output = []
        if results["ids"] and results["ids"][0]:
            for i, chroma_id in enumerate(results["ids"][0]):
                metadata = results["metadatas"][0][i] if results["metadatas"] else {}
                distance = results["distances"][0][i] if results["distances"] else 1.0
                # 余弦距离转相似度分数：cosine distance ∈ [0, 2]，转换为 [0, 1]
                similarity = max(0.0, min(1.0, 1.0 - distance / 2.0))

                output.append({
                    "chroma_id": chroma_id,
                    "document_id": metadata.get("document_id", ""),
                    "filename": metadata.get("filename", ""),
                    "chunk_index": metadata.get("chunk_index", 0),
                    "content": results["documents"][0][i] if results["documents"] else "",
                    "score": round(similarity, 4),
                })

        return output

    def delete_document(self, doc_id: str) -> None:
        """删除文档的所有向量。

        Args:
            doc_id: 文档 ID
        """
        try:
            self.collection.delete(where={"document_id": doc_id})
        except Exception:
            # 如果集合中已经没有数据，忽略错误
            pass

    def count(self) -> int:
        """获取向量总数。"""
        return self.collection.count()

    def get_collection_stats(self) -> Dict:
        """获取集合统计信息。"""
        return {
            "name": self.collection_name,
            "count": self.collection.count(),
            "metadata": self.collection.metadata,
        }
