"""文档服务

编排文档的完整生命周期：
上传 → 存储 → 解析 → 分块 → 嵌入 → 索引 → 就绪
"""

import os
import uuid
import shutil
from typing import Optional, List, Dict, Any
import streamlit as st

from app.config import Config
from app.database.repository import DocumentRepository, ChunkRepository
from app.ingestion.parser import extract_text, get_supported_types
from app.ingestion.chunker import split_text
from app.services.embedding_service import EmbeddingService
from app.search.retriever import ChromaRetriever


class DocumentService:
    """文档生命周期管理服务。"""

    def __init__(
        self,
        doc_repo: DocumentRepository,
        chunk_repo: ChunkRepository,
        embedding_service: EmbeddingService,
        retriever: ChromaRetriever,
        config: Config,
    ):
        self.doc_repo = doc_repo
        self.chunk_repo = chunk_repo
        self.embedding_service = embedding_service
        self.retriever = retriever
        self.config = config

    @property
    def data_dir(self) -> str:
        return self.config.app.data_dir

    @property
    def documents_dir(self) -> str:
        d = os.path.join(self.data_dir, "documents")
        os.makedirs(d, exist_ok=True)
        return d

    def create_document(self, uploaded_file) -> Dict[str, Any]:
        """从上传文件创建文档（完整摄入管道）。

        Args:
            uploaded_file: Streamlit UploadedFile 对象

        Returns:
            创建的 Document 字典
        """
        # 1. 验证文件类型
        filename = uploaded_file.name
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in get_supported_types():
            raise ValueError(f"不支持的文件类型: .{ext}。支持: {get_supported_types()}")

        # 2. 验证文件大小
        max_bytes = self.config.app.max_file_size_mb * 1024 * 1024
        file_bytes = uploaded_file.getvalue()
        if len(file_bytes) > max_bytes:
            raise ValueError(
                f"文件过大: {len(file_bytes) / 1024 / 1024:.1f}MB。"
                f"最大允许: {self.config.app.max_file_size_mb}MB"
            )

        # 3. 保存文件到磁盘
        doc_id = uuid.uuid4().hex
        stored_name = f"{doc_id}_{filename}"
        stored_path = os.path.join(self.documents_dir, stored_name)
        with open(stored_path, "wb") as f:
            f.write(file_bytes)

        # 4. 创建文档记录（状态: uploaded）
        doc = self.doc_repo.create(
            id=doc_id,
            filename=filename,
            stored_path=stored_path,
            file_type=ext,
            file_size=len(file_bytes),
            status="uploaded",
        )

        # 5. 处理文档
        try:
            self._process_document(doc_id, stored_path, ext)
            doc = self.doc_repo.get_by_id(doc_id)
            return doc.to_dict() if doc else {}
        except Exception as e:
            self.doc_repo.update(doc_id, status="error", error_message=str(e))
            doc = self.doc_repo.get_by_id(doc_id)
            return doc.to_dict() if doc else {}

    def _process_document(self, doc_id: str, file_path: str, file_type: str):
        """处理文档：解析 → 分块 → 嵌入 → 存储。"""

        # 更新状态为 processing
        self.doc_repo.update(doc_id, status="processing")

        # 获取文档信息
        doc = self.doc_repo.get_by_id(doc_id)
        if doc is None:
            raise ValueError(f"文档不存在: {doc_id}")

        # 解析文本
        raw_text = extract_text(file_path, file_type)
        char_count = len(raw_text)

        # 分块
        chunks = split_text(
            raw_text,
            chunk_size=self.config.chunking.chunk_size,
            chunk_overlap=self.config.chunking.chunk_overlap,
        )

        if not chunks:
            raise ValueError("文档解析后没有有效文本内容")

        # 嵌入（分批处理以避免 OOM）
        batch_size = 32
        all_embeddings = []
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            embeddings = self.embedding_service.embed_batch(batch)
            all_embeddings.extend(embeddings)

        # 存入 ChromaDB
        chroma_ids = self.retriever.add_chunks(
            chunks=chunks,
            embeddings=all_embeddings,
            doc_id=doc_id,
            filename=doc.filename,
        )

        # 存入 SQLite
        chunk_records = []
        for i, (chunk_text, chroma_id) in enumerate(zip(chunks, chroma_ids)):
            chunk_records.append({
                "document_id": doc_id,
                "chunk_index": i,
                "content": chunk_text,
                "chroma_id": chroma_id,
            })
        self.chunk_repo.create_batch(chunk_records)

        # 更新文档状态
        self.doc_repo.update(
            doc_id,
            status="ready",
            chunk_count=len(chunks),
            char_count=char_count,
        )

    def get_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """获取文档详情。"""
        doc = self.doc_repo.get_by_id(doc_id)
        return doc.to_dict() if doc else None

    def update_document(self, doc_id: str, **fields) -> Optional[Dict[str, Any]]:
        """更新文档元数据（title, description, tags）。"""
        allowed = {"title", "description", "tags"}
        update_fields = {k: v for k, v in fields.items() if k in allowed}
        doc = self.doc_repo.update(doc_id, **update_fields)
        return doc.to_dict() if doc else None

    def delete_document(self, doc_id: str) -> bool:
        """删除文档及其所有关联数据。

        Args:
            doc_id: 文档 ID

        Returns:
            是否成功
        """
        doc = self.doc_repo.get_by_id(doc_id)
        if doc is None:
            return False

        # 删除磁盘文件
        if doc.stored_path and os.path.exists(doc.stored_path):
            try:
                os.remove(doc.stored_path)
            except OSError:
                pass

        # 删除 ChromaDB 向量
        self.retriever.delete_document(doc_id)

        # 删除 SQLite 记录（级联删除分块）
        return self.doc_repo.delete(doc_id)

    def list_documents(
        self,
        status: Optional[str] = None,
        file_type: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """分页列出文档。"""
        docs, total = self.doc_repo.list_all(
            status=status,
            file_type=file_type,
            search=search,
            page=page,
            page_size=page_size,
        )
        total_pages = max(1, (total + page_size - 1) // page_size) if total > 0 else 1

        return {
            "items": [d.to_dict() for d in docs],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
        }

    def get_chunks(self, doc_id: str) -> List[Dict[str, Any]]:
        """获取文档的所有分块。"""
        chunks = self.chunk_repo.get_by_document(doc_id)
        return [c.to_dict() for c in chunks]

    def reindex_document(self, doc_id: str) -> Dict[str, Any]:
        """重新索引文档（用于配置变更后重建）。

        Args:
            doc_id: 文档 ID

        Returns:
            更新后的文档字典
        """
        doc = self.doc_repo.get_by_id(doc_id)
        if doc is None:
            raise ValueError(f"文档不存在: {doc_id}")

        if not os.path.exists(doc.stored_path):
            raise ValueError(f"原始文件不存在: {doc.stored_path}")

        # 删除旧的分块和向量
        self.retriever.delete_document(doc_id)
        self.chunk_repo.delete_by_document(doc_id)

        # 重新处理
        self._process_document(doc_id, doc.stored_path, doc.file_type)

        doc = self.doc_repo.get_by_id(doc_id)
        return doc.to_dict() if doc else {}

    def get_stats(self) -> Dict[str, Any]:
        """获取知识库统计信息。"""
        stats = self.doc_repo.get_stats()
        stats["vector_count"] = self.retriever.count()
        stats["provider"] = self.embedding_service.get_provider_name()
        return stats
