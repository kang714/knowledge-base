"""嵌入服务

提供统一的嵌入接口，自动选择最佳可用提供者：
1. 优先使用 Ollama（需要先启动 ollama serve）
2. 回退到 sentence-transformers（纯本地，无需外部服务）
"""

from typing import List
import streamlit as st

from app.config import EmbeddingConfig
from app.embeddings.base import EmbeddingProvider
from app.embeddings.ollama_provider import OllamaEmbeddingProvider
from app.embeddings.sentence_transformer_provider import SentenceTransformerProvider


class EmbeddingService:
    """嵌入服务门面。

    自动选择可用提供者，并提供缓存以避免重复初始化。
    """

    def __init__(self, config: EmbeddingConfig):
        self.config = config
        self._provider: EmbeddingProvider = None
        self._initialized = False
        self._provider_name = "unknown"

    def _init_provider(self):
        """初始化嵌入提供者（尝试 Ollama，失败则回退）。"""
        if self._initialized:
            return

        # 尝试 Ollama
        if self.config.provider == "ollama":
            provider = OllamaEmbeddingProvider(self.config.model)
            if provider.is_available():
                self._provider = provider
                self._provider_name = provider.name
                self._initialized = True
                return

        # 回退到 sentence-transformers
        try:
            provider = SentenceTransformerProvider(self.config.fallback_model)
            if provider.is_available():
                self._provider = provider
                self._provider_name = provider.name
                self._initialized = True
                return
        except Exception as e:
            pass

        raise RuntimeError(
            "没有可用的嵌入模型。请：\n"
            "1. 启动 Ollama: ollama serve\n"
            "2. 拉取嵌入模型: ollama pull nomic-embed-text\n"
            "3. 或安装后备模型: pip install sentence-transformers"
        )

    def embed_text(self, text: str) -> List[float]:
        """将单条文本转换为向量。"""
        self._init_provider()
        return self._provider.embed(text)

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """批量将文本转换为向量。"""
        self._init_provider()
        return self._provider.embed_batch(texts)

    def get_provider_name(self) -> str:
        """获取当前活跃的提供者名称。"""
        self._init_provider()
        return self._provider_name

    def check_ollama_status(self) -> dict:
        """检查 Ollama 服务状态。

        Returns:
            包含 status, models, error 的字典
        """
        result = {"status": "unknown", "models": [], "error": ""}
        try:
            import ollama
            client = ollama.Client(host="http://localhost:11434")
            models = client.list()
            result["status"] = "running"
            result["models"] = [m.get("model", "") for m in models.get("models", [])]
        except Exception as e:
            result["status"] = "not_running"
            result["error"] = str(e)
        return result
