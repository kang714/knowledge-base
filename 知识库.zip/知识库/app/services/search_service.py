"""搜索和问答服务

提供语义搜索和基于 RAG 的问答功能。
"""

from typing import List, Dict, Optional, Generator

from app.database.repository import DocumentRepository, QAHistoryRepository
from app.services.embedding_service import EmbeddingService
from app.search.retriever import ChromaRetriever
from app.llm.ollama_provider import OllamaLLMProvider


RAG_SYSTEM_PROMPT = """你是一个基于知识库的问答助手。请根据提供的上下文信息回答用户的问题。

规则：
1. 只使用提供的上下文信息来回答问题
2. 如果上下文信息不足以回答问题，请诚实地说"根据知识库中的信息，我无法回答这个问题"
3. 引用具体的来源文件来支持你的回答
4. 回答要简洁、准确、有条理
5. 如果上下文提供了相互矛盾的信息，请指出矛盾之处"""

RAG_PROMPT_TEMPLATE = """请根据以下上下文信息回答问题。

上下文信息：
{context}

问题：{question}

请回答："""


class SearchService:
    """搜索和 RAG 问答服务。"""

    def __init__(
        self,
        retriever: ChromaRetriever,
        embedding_service: EmbeddingService,
        doc_repo: DocumentRepository,
        llm_provider: OllamaLLMProvider,
        qa_repo: QAHistoryRepository,
    ):
        self.retriever = retriever
        self.embedding_service = embedding_service
        self.doc_repo = doc_repo
        self.llm_provider = llm_provider
        self.qa_repo = qa_repo

    def search(
        self,
        query: str,
        top_k: int = 10,
        filter_doc_ids: Optional[List[str]] = None,
    ) -> List[Dict]:
        """语义搜索。

        Args:
            query: 搜索查询
            top_k: 返回结果数量
            filter_doc_ids: 限定搜索的文档 ID 列表

        Returns:
            搜索结果列表
        """
        if not query.strip():
            return []

        results = self.retriever.similarity_search(
            query=query,
            top_k=top_k,
            filter_doc_ids=filter_doc_ids,
        )
        return results

    def answer_question(
        self,
        question: str,
        top_k: int = 5,
        filter_doc_ids: Optional[List[str]] = None,
    ) -> Dict:
        """基于 RAG 回答问题（非流式）。

        Args:
            question: 用户问题
            top_k: 检索的上下文块数量
            filter_doc_ids: 限定搜索范围

        Returns:
            包含 answer, sources, model_used 的字典
        """
        if not question.strip():
            return {"answer": "请输入一个问题。", "sources": [], "model_used": ""}

        # 1. 检索相关上下文
        search_results = self.search(question, top_k=top_k, filter_doc_ids=filter_doc_ids)

        if not search_results:
            return {
                "answer": "知识库中没有找到相关信息。请先上传一些文档。",
                "sources": [],
                "model_used": self.llm_provider.config.model,
            }

        # 2. 构建 prompt
        context_parts = []
        for r in search_results:
            context_parts.append(
                f"[来源: {r['filename']}]\n{r['content']}"
            )
        context = "\n\n---\n\n".join(context_parts)

        prompt = RAG_PROMPT_TEMPLATE.format(context=context, question=question)

        # 3. 调用 LLM 生成回答
        if not self.llm_provider.is_available():
            return {
                "answer": (
                    "⚠️ Ollama 服务未运行。请先启动 Ollama（运行 `ollama serve`）"
                    "并确保已安装模型。\n\n"
                    f"搜索到的相关内容（共 {len(search_results)} 条）：\n\n{context[:2000]}..."
                ),
                "sources": search_results,
                "model_used": "无（Ollama 不可用）",
            }

        answer = self.llm_provider.generate(
            prompt=prompt,
            system=RAG_SYSTEM_PROMPT,
        )

        # 4. 保存问答历史
        source_doc_ids = list(set(r["document_id"] for r in search_results))
        source_chunk_ids = list(set(r["chroma_id"] for r in search_results))
        self.qa_repo.save(
            question=question,
            answer=answer,
            model_used=self.llm_provider.config.model,
            source_doc_ids=source_doc_ids,
            source_chunk_ids=source_chunk_ids,
        )

        return {
            "answer": answer,
            "sources": search_results,
            "model_used": self.llm_provider.config.model,
        }

    def answer_question_stream(
        self,
        question: str,
        top_k: int = 5,
        filter_doc_ids: Optional[List[str]] = None,
    ) -> Generator[Dict, None, None]:
        """基于 RAG 回答问题（流式）。

        Yields:
            包含 chunk (文本片段), sources (首次返回), done (结束标记) 的字典
        """
        # 检索
        search_results = self.search(question, top_k=top_k, filter_doc_ids=filter_doc_ids)

        if not search_results:
            yield {
                "chunk": "知识库中没有找到相关信息。请先上传一些文档。",
                "sources": [],
                "done": True,
            }
            return

        if not self.llm_provider.is_available():
            context = "\n\n".join(
                f"[来源: {r['filename']}]\n{r['content']}" for r in search_results
            )
            yield {
                "chunk": (
                    "⚠️ Ollama 服务未运行。\n\n"
                    f"搜索到的相关内容：\n\n{context[:2000]}..."
                ),
                "sources": search_results,
                "done": True,
            }
            return

        # 构建 prompt
        context_parts = [
            f"[来源: {r['filename']}]\n{r['content']}" for r in search_results
        ]
        context = "\n\n---\n\n".join(context_parts)
        prompt = RAG_PROMPT_TEMPLATE.format(context=context, question=question)

        # 流式生成
        full_answer = ""
        sources_sent = False
        for text_chunk in self.llm_provider.generate_stream(
            prompt=prompt,
            system=RAG_SYSTEM_PROMPT,
        ):
            full_answer += text_chunk
            response = {"chunk": text_chunk, "done": False}
            if not sources_sent:
                response["sources"] = search_results
                sources_sent = True
            yield response

        # 保存历史
        source_doc_ids = list(set(r["document_id"] for r in search_results))
        source_chunk_ids = list(set(r["chroma_id"] for r in search_results))
        self.qa_repo.save(
            question=question,
            answer=full_answer,
            model_used=self.llm_provider.config.model,
            source_doc_ids=source_doc_ids,
            source_chunk_ids=source_chunk_ids,
        )

        yield {"chunk": "", "done": True}

    def get_qa_history(self, limit: int = 50) -> List[Dict]:
        """获取问答历史。"""
        entries = self.qa_repo.list_recent(limit=limit)
        return [e.to_dict() for e in entries]

    def delete_qa_history(self, entry_id: str) -> bool:
        """删除问答历史记录。"""
        return self.qa_repo.delete(entry_id)
