"""数据库操作封装

提供文档、分块、问答历史的 CRUD 操作。
"""

import math
from typing import Optional, List, Tuple, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func, and_

from app.database.models import Document, Chunk, QAHistory, generate_uuid, utcnow
from app.database.connection import get_session


class DocumentRepository:
    """文档元数据存储。"""

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def _session(self) -> Session:
        return self.session_factory()

    def create(self, **kwargs) -> Document:
        """创建文档记录。"""
        doc = Document(id=generate_uuid(), **kwargs)
        with self._session() as session:
            session.add(doc)
            session.commit()
            session.refresh(doc)
            return doc

    def get_by_id(self, doc_id: str) -> Optional[Document]:
        """根据 ID 获取文档。"""
        with self._session() as session:
            return session.get(Document, doc_id)

    def update(self, doc_id: str, **kwargs) -> Optional[Document]:
        """更新文档字段。"""
        kwargs["updated_at"] = utcnow().isoformat()
        with self._session() as session:
            doc = session.get(Document, doc_id)
            if doc is None:
                return None
            for key, value in kwargs.items():
                if hasattr(doc, key):
                    setattr(doc, key, value)
            session.commit()
            session.refresh(doc)
            return doc

    def delete(self, doc_id: str) -> bool:
        """删除文档（级联删除关联的分块）。"""
        with self._session() as session:
            doc = session.get(Document, doc_id)
            if doc is None:
                return False
            session.delete(doc)
            session.commit()
            return True

    def list_all(
        self,
        status: Optional[str] = None,
        file_type: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Tuple[List[Document], int]:
        """分页列出文档，支持筛选和搜索。

        Args:
            status: 按状态筛选
            file_type: 按文件类型筛选
            search: 按文件名/标题模糊搜索
            page: 页码（从1开始）
            page_size: 每页数量

        Returns:
            (文档列表, 总数)
        """
        with self._session() as session:
            query = session.query(Document)

            if status:
                query = query.filter(Document.status == status)
            if file_type:
                query = query.filter(Document.file_type == file_type)
            if search:
                like_pattern = f"%{search}%"
                query = query.filter(
                    (Document.filename.ilike(like_pattern)) |
                    (Document.title.ilike(like_pattern))
                )

            total = query.count()
            docs = query.order_by(Document.created_at.desc()) \
                        .offset((page - 1) * page_size) \
                        .limit(page_size) \
                        .all()
            return list(docs), total

    def get_stats(self) -> Dict[str, Any]:
        """获取知识库统计信息。"""
        with self._session() as session:
            total_docs = session.query(func.count(Document.id)).scalar() or 0
            ready_docs = session.query(func.count(Document.id)) \
                                .filter(Document.status == "ready").scalar() or 0
            error_docs = session.query(func.count(Document.id)) \
                                .filter(Document.status == "error").scalar() or 0
            total_chunks = session.query(func.count(Chunk.id)).scalar() or 0
            total_chars = session.query(func.sum(Document.char_count)).scalar() or 0
            total_size = session.query(func.sum(Document.file_size)).scalar() or 0

            return {
                "total_docs": total_docs,
                "ready_docs": ready_docs,
                "error_docs": error_docs,
                "total_chunks": total_chunks,
                "total_chars": total_chars,
                "total_size_bytes": total_size,
            }

    def get_recent_docs(self, limit: int = 5) -> List[Document]:
        """获取最近添加的文档。"""
        with self._session() as session:
            return list(
                session.query(Document)
                .order_by(Document.created_at.desc())
                .limit(limit)
                .all()
            )


class ChunkRepository:
    """文档分块存储。"""

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def _session(self) -> Session:
        return self.session_factory()

    def create_batch(self, chunks_data: List[Dict[str, Any]]) -> List[Chunk]:
        """批量创建分块记录。

        Args:
            chunks_data: 每个元素包含 document_id, chunk_index, content, chroma_id

        Returns:
            创建的 Chunk 对象列表
        """
        chunks = []
        with self._session() as session:
            for data in chunks_data:
                chunk = Chunk(
                    id=generate_uuid(),
                    document_id=data["document_id"],
                    chunk_index=data["chunk_index"],
                    content=data["content"],
                    chroma_id=data["chroma_id"],
                )
                session.add(chunk)
                chunks.append(chunk)
            session.commit()
            # 不 refresh — 批量操作返回即可
            return chunks

    def get_by_document(self, doc_id: str) -> List[Chunk]:
        """获取文档的所有分块（按序号排序）。"""
        with self._session() as session:
            return list(
                session.query(Chunk)
                .filter(Chunk.document_id == doc_id)
                .order_by(Chunk.chunk_index)
                .all()
            )

    def get_by_chroma_ids(self, chroma_ids: List[str]) -> List[Chunk]:
        """根据 ChromaDB ID 批量获取分块。"""
        with self._session() as session:
            return list(
                session.query(Chunk)
                .filter(Chunk.chroma_id.in_(chroma_ids))
                .all()
            )

    def delete_by_document(self, doc_id: str) -> int:
        """删除文档的所有分块。"""
        with self._session() as session:
            count = session.query(Chunk).filter(Chunk.document_id == doc_id).delete()
            session.commit()
            return count


class QAHistoryRepository:
    """问答历史存储。"""

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def _session(self) -> Session:
        return self.session_factory()

    def save(
        self,
        question: str,
        answer: str,
        model_used: str = "",
        source_doc_ids: List[str] = None,
        source_chunk_ids: List[str] = None,
    ) -> QAHistory:
        """保存一条问答记录。"""
        entry = QAHistory(
            id=generate_uuid(),
            question=question,
            answer=answer,
            model_used=model_used,
            source_doc_ids=source_doc_ids or [],
            source_chunk_ids=source_chunk_ids or [],
        )
        with self._session() as session:
            session.add(entry)
            session.commit()
            session.refresh(entry)
            return entry

    def list_recent(self, limit: int = 50) -> List[QAHistory]:
        """获取最近的问答记录。"""
        with self._session() as session:
            return list(
                session.query(QAHistory)
                .order_by(QAHistory.created_at.desc())
                .limit(limit)
                .all()
            )

    def delete(self, entry_id: str) -> bool:
        """删除一条问答记录。"""
        with self._session() as session:
            entry = session.get(QAHistory, entry_id)
            if entry is None:
                return False
            session.delete(entry)
            session.commit()
            return True
