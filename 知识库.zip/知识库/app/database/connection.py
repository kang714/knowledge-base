"""数据库连接模块

使用 SQLAlchemy 管理 SQLite 连接，启用 WAL 模式以提升并发性能。
"""

import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session

_engine = None
_SessionFactory = None


def get_engine(data_dir: str = "data"):
    """获取 SQLAlchemy 引擎（单例）。

    Args:
        data_dir: 数据目录路径

    Returns:
        SQLAlchemy Engine
    """
    global _engine
    if _engine is not None:
        return _engine

    os.makedirs(data_dir, exist_ok=True)
    db_path = os.path.join(data_dir, "knowledge.db")
    db_url = f"sqlite:///{db_path}"

    _engine = create_engine(
        db_url,
        echo=False,
        connect_args={"check_same_thread": False},
    )

    # 启用 WAL 模式提升并发性能
    @event.listens_for(_engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.close()

    return _engine


def create_session_factory(data_dir: str = "data") -> sessionmaker:
    """创建 Session 工厂。

    Args:
        data_dir: 数据目录路径

    Returns:
        SQLAlchemy sessionmaker
    """
    global _SessionFactory
    if _SessionFactory is not None:
        return _SessionFactory

    engine = get_engine(data_dir)
    _SessionFactory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    return _SessionFactory


def get_session(data_dir: str = "data") -> Session:
    """获取一个新的数据库会话。

    Args:
        data_dir: 数据目录路径

    Returns:
        SQLAlchemy Session
    """
    factory = create_session_factory(data_dir)
    return factory()


def init_db(data_dir: str = "data"):
    """初始化数据库：创建所有表。

    Args:
        data_dir: 数据目录路径
    """
    from app.database.models import Base
    engine = get_engine(data_dir)
    Base.metadata.create_all(bind=engine)
