"""SQLAlchemy ORM 模型定义

三张表：
- documents: 文档元数据
- chunks: 文档分块
- qa_history: 问答历史
"""

import uuid
import json
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, Text, Float, ForeignKey, Index
from sqlalchemy.orm import DeclarativeBase, relationship
from sqlalchemy.types import TypeDecorator


class Base(DeclarativeBase):
    pass


class JSONColumn(TypeDecorator):
    """将 Python list/dict 序列化为 JSON 字符串存储到 SQLite TEXT 列。"""
    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return json.dumps(value, ensure_ascii=False)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return json.loads(value)


def generate_uuid() -> str:
    return uuid.uuid4().hex


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Document(Base):
    __tablename__ = "documents"

    id = Column(String(32), primary_key=True, default=generate_uuid)
    filename = Column(String(500), nullable=False)
    stored_path = Column(String(1000), nullable=False)
    file_type = Column(String(10), nullable=False)
    file_size = Column(Integer, nullable=False, default=0)
    title = Column(String(500), default="")
    description = Column(Text, default="")
    tags = Column(JSONColumn, default=list)
    status = Column(String(20), nullable=False, default="uploaded", index=True)
    error_message = Column(Text, default="")
    chunk_count = Column(Integer, default=0)
    char_count = Column(Integer, default=0)
    created_at = Column(Text, default=lambda: utcnow().isoformat())
    updated_at = Column(Text, default=lambda: utcnow().isoformat())

    chunks = relationship("Chunk", back_populates="document", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "stored_path": self.stored_path,
            "file_type": self.file_type,
            "file_size": self.file_size,
            "title": self.title or self.filename,
            "description": self.description,
            "tags": self.tags or [],
            "status": self.status,
            "error_message": self.error_message,
            "chunk_count": self.chunk_count,
            "char_count": self.char_count,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


class Chunk(Base):
    __tablename__ = "chunks"

    id = Column(String(32), primary_key=True, default=generate_uuid)
    document_id = Column(String(32), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    chroma_id = Column(String(100), unique=True, nullable=False)
    created_at = Column(Text, default=lambda: utcnow().isoformat())

    document = relationship("Document", back_populates="chunks")

    def to_dict(self):
        return {
            "id": self.id,
            "document_id": self.document_id,
            "chunk_index": self.chunk_index,
            "content": self.content,
            "chroma_id": self.chroma_id,
            "created_at": self.created_at,
        }


class QAHistory(Base):
    __tablename__ = "qa_history"

    id = Column(String(32), primary_key=True, default=generate_uuid)
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    model_used = Column(String(100), default="")
    source_doc_ids = Column(JSONColumn, default=list)
    source_chunk_ids = Column(JSONColumn, default=list)
    created_at = Column(Text, default=lambda: utcnow().isoformat(), index=True)

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "answer": self.answer,
            "model_used": self.model_used,
            "source_doc_ids": self.source_doc_ids or [],
            "source_chunk_ids": self.source_chunk_ids or [],
            "created_at": self.created_at,
        }
