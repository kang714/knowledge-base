"""嵌入提供者抽象基类"""

from abc import ABC, abstractmethod
from typing import List


class EmbeddingProvider(ABC):
    """嵌入模型提供者基类。

    所有嵌入提供者必须实现 embed 和 embed_batch 方法。
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """提供者名称。"""
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """检查提供者是否可用。"""
        ...

    @abstractmethod
    def embed(self, text: str) -> List[float]:
        """将单条文本转换为向量。

        Args:
            text: 输入文本

        Returns:
            向量（浮点数列表）
        """
        ...

    @abstractmethod
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """批量将文本转换为向量。

        Args:
            texts: 输入文本列表

        Returns:
            向量列表
        """
        ...
