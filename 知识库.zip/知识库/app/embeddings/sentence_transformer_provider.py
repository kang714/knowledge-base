"""Sentence-Transformer 嵌入提供者

纯本地运行，无需外部服务。作为 Ollama 不可用时的后备方案。
默认模型: all-MiniLM-L6-v2（轻量，82MB）
"""

from typing import List

from app.embeddings.base import EmbeddingProvider


class SentenceTransformerProvider(EmbeddingProvider):
    """使用 HuggingFace sentence-transformers 模型生成嵌入向量。"""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model_name = model_name
        self._model = None

    @property
    def name(self) -> str:
        return f"sentence_transformer:{self.model_name}"

    def _load_model(self):
        """延迟加载模型（首次使用时加载）。"""
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError:
                raise ImportError(
                    "请安装 sentence-transformers: pip install sentence-transformers"
                )
            self._model = SentenceTransformer(self.model_name)

    def is_available(self) -> bool:
        """sentence-transformers 始终可用（只要能导入）。"""
        try:
            import sentence_transformers
            return True
        except ImportError:
            return False

    def embed(self, text: str) -> List[float]:
        self._load_model()
        embedding = self._model.encode(text, normalize_embeddings=True)
        return embedding.tolist()

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        self._load_model()
        embeddings = self._model.encode(texts, normalize_embeddings=True)
        return embeddings.tolist()
