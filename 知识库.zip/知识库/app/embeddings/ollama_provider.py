"""Ollama 嵌入提供者

使用 Ollama 的本地嵌入 API。
默认模型: nomic-embed-text
"""

from typing import List
import ollama

from app.embeddings.base import EmbeddingProvider


class OllamaEmbeddingProvider(EmbeddingProvider):
    """通过 Ollama API 生成文本嵌入向量。"""

    def __init__(self, model: str = "nomic-embed-text", base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url

    @property
    def name(self) -> str:
        return f"ollama:{self.model}"

    def is_available(self) -> bool:
        """通过列出模型来检查 Ollama 服务是否可用。"""
        try:
            client = ollama.Client(host=self.base_url)
            models = client.list()
            model_names = [m.get("model", "") for m in models.get("models", [])]
            # 检查模型是否存在（去掉 :latest 后缀比较）
            for name in model_names:
                if name == self.model or name.startswith(self.model.split(":")[0]):
                    return True
            return False
        except Exception:
            return False

    def embed(self, text: str) -> List[float]:
        """生成单条文本的嵌入向量。"""
        client = ollama.Client(host=self.base_url)
        response = client.embed(model=self.model, input=text)
        return response.get("embeddings", [[]])[0]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """批量生成嵌入向量。"""
        client = ollama.Client(host=self.base_url)
        response = client.embed(model=self.model, input=texts)
        return response.get("embeddings", [])
