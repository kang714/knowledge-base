"""Ollama LLM 提供者

封装 Ollama 的 Chat API，支持流式和非流式生成。
"""

from typing import Generator, Optional
import ollama

from app.config import LLMConfig


class OllamaLLMProvider:
    """Ollama 大模型提供者。"""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = ollama.Client(host=config.base_url)

    def is_available(self) -> bool:
        """检查 Ollama 服务是否可用。"""
        try:
            self.client.list()
            return True
        except Exception:
            return False

    def list_models(self) -> list:
        """列出所有已安装的模型。"""
        try:
            result = self.client.list()
            return [m.get("model", "") for m in result.get("models", [])]
        except Exception:
            return []

    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """生成回答（非流式）。

        Args:
            prompt: 提示词
            system: 系统提示
            temperature: 温度参数
            max_tokens: 最大 token 数

        Returns:
            生成的文本
        """
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = self.client.chat(
            model=self.config.model,
            messages=messages,
            options={
                "temperature": temperature if temperature is not None else self.config.temperature,
                "num_predict": max_tokens if max_tokens is not None else self.config.max_tokens,
            },
        )
        return response.get("message", {}).get("content", "")

    def generate_stream(
        self,
        prompt: str,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Generator[str, None, None]:
        """生成回答（流式）。

        Args:
            prompt: 提示词
            system: 系统提示
            temperature: 温度参数
            max_tokens: 最大 token 数

        Yields:
            生成的文本片段
        """
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        stream = self.client.chat(
            model=self.config.model,
            messages=messages,
            stream=True,
            options={
                "temperature": temperature if temperature is not None else self.config.temperature,
                "num_predict": max_tokens if max_tokens is not None else self.config.max_tokens,
            },
        )
        for chunk in stream:
            content = chunk.get("message", {}).get("content", "")
            if content:
                yield content

    def check_model_available(self, model_name: str) -> bool:
        """检查指定模型是否已安装。"""
        models = self.list_models()
        for m in models:
            if m == model_name or m.startswith(model_name.split(":")[0]):
                return True
        return False
