"""文件解析模块

支持 txt, md, pdf, docx 格式。
通过注册表模式，方便扩展新格式。
"""

from typing import Callable, Dict

# 解析器函数签名：接受文件路径，返回文本字符串
ParserFunc = Callable[[str], str]

PARSER_REGISTRY: Dict[str, ParserFunc] = {}


def register_parser(file_type: str):
    """装饰器：注册文件类型对应的解析器函数。"""
    def decorator(func: ParserFunc) -> ParserFunc:
        PARSER_REGISTRY[file_type] = func
        return func
    return decorator


@register_parser("txt")
def parse_txt(file_path: str) -> str:
    """解析纯文本文件。"""
    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


@register_parser("md")
def parse_md(file_path: str) -> str:
    """解析 Markdown 文件（作为纯文本读取）。"""
    return parse_txt(file_path)


@register_parser("pdf")
def parse_pdf(file_path: str) -> str:
    """解析 PDF 文件，提取所有页面文本。"""
    try:
        from PyPDF2 import PdfReader
    except ImportError:
        raise ImportError("请安装 PyPDF2: pip install PyPDF2")

    reader = PdfReader(file_path)
    texts = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            texts.append(text)
    return "\n\n".join(texts)


@register_parser("docx")
def parse_docx(file_path: str) -> str:
    """解析 Word 文档。"""
    try:
        import docx2txt
    except ImportError:
        raise ImportError("请安装 docx2txt: pip install docx2txt")

    return docx2txt.process(file_path)


def extract_text(file_path: str, file_type: str) -> str:
    """从文件提取文本。

    Args:
        file_path: 文件路径
        file_type: 文件类型 (txt, md, pdf, docx)

    Returns:
        提取的文本字符串

    Raises:
        ValueError: 不支持的文件类型
    """
    parser = PARSER_REGISTRY.get(file_type.lower())
    if parser is None:
        raise ValueError(f"不支持的文件类型: {file_type}。支持的类型: {list(PARSER_REGISTRY.keys())}")
    return parser(file_path)


def get_supported_types() -> list:
    """获取所有支持的文件类型。"""
    return list(PARSER_REGISTRY.keys())
