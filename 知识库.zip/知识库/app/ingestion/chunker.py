"""文本分块模块

递归字符分割器：按优先级逐一尝试分隔符，将长文本切分为重叠的块。
"""

from typing import List, Optional


def split_text(
    text: str,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    separators: Optional[List[str]] = None,
) -> List[str]:
    """将长文本切分为指定大小的重叠块。

    采用递归策略：
    1. 首先尝试用最粗粒度的分隔符（如双换行）切分
    2. 如果某段仍超过 chunk_size，尝试下一个分隔符
    3. 最终回退到字符级别切分
    4. 相邻块之间保持 chunk_overlap 个字符的重叠

    Args:
        text: 输入文本
        chunk_size: 每块最大字符数
        chunk_overlap: 相邻块重叠的字符数
        separators: 分隔符优先级列表，默认为换行 → 句号 → 空格 → 字符

    Returns:
        文本块列表
    """
    if separators is None:
        separators = ["\n\n", "\n", "。", ". ", " ", ""]

    if not text or len(text) <= chunk_size:
        return [text] if text else []

    chunks = []
    _split_recursive(text, separators, 0, chunk_size, chunk_overlap, chunks)

    # 合并过短的块（少于 chunk_size/4）
    merged = _merge_short_chunks(chunks, chunk_size, chunk_overlap)

    return merged


def _split_recursive(
    text: str,
    separators: List[str],
    sep_index: int,
    chunk_size: int,
    chunk_overlap: int,
    output: List[str],
):
    """递归切分文本。"""
    if len(text) <= chunk_size:
        if text.strip():
            output.append(text)
        return

    # 尝试当前分隔符
    if sep_index < len(separators):
        separator = separators[sep_index]
        if separator and separator in text:
            parts = text.split(separator)
            # 将分隔符重新拼回（除了最后一个）
            # 重新组合各部分，保持块大小
            current_chunk = ""
            for i, part in enumerate(parts):
                # 加上分隔符（最后一个不加）
                candidate = part if i == len(parts) - 1 else part + separator

                if len(current_chunk) + len(candidate) <= chunk_size:
                    current_chunk += candidate
                else:
                    # 当前块满了
                    if current_chunk.strip():
                        # 递归处理以确保不大于 chunk_size
                        _split_recursive(current_chunk, separators, sep_index + 1, chunk_size, chunk_overlap, output)
                    # 开始新块
                    if len(candidate) > chunk_size:
                        _split_recursive(candidate, separators, sep_index + 1, chunk_size, chunk_overlap, output)
                        current_chunk = ""
                    else:
                        current_chunk = candidate

            if current_chunk.strip():
                _split_recursive(current_chunk, separators, sep_index + 1, chunk_size, chunk_overlap, output)
            return

        # 当前分隔符不适用，尝试下一个
        _split_recursive(text, separators, sep_index + 1, chunk_size, chunk_overlap, output)
        return

    # 最后回退：字符级别切分
    _split_by_chars(text, chunk_size, chunk_overlap, output)


def _split_by_chars(text: str, chunk_size: int, chunk_overlap: int, output: List[str]):
    """字符级别切分（最终回退策略）。"""
    step = chunk_size - chunk_overlap
    if step <= 0:
        step = chunk_size // 2 or 1

    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        if chunk.strip():
            output.append(chunk)
        start += step


def _merge_short_chunks(chunks: List[str], chunk_size: int, chunk_overlap: int) -> List[str]:
    """合并过短的块以提升检索质量。"""
    if len(chunks) <= 1:
        return chunks

    min_size = max(1, chunk_size // 4)
    merged = []
    buffer = ""

    for chunk in chunks:
        if len(buffer) + len(chunk) <= chunk_size:
            buffer = buffer + chunk if not buffer else buffer + "\n" + chunk
        else:
            if buffer:
                merged.append(buffer)
            buffer = chunk

    if buffer:
        # 如果最后一个 buffer 太短且能与前一个合并
        if merged and len(buffer) < min_size and len(merged[-1]) + len(buffer) <= chunk_size:
            merged[-1] = merged[-1] + "\n" + buffer
        else:
            merged.append(buffer)

    return merged
