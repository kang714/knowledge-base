"""知识库系统 - Streamlit 主程序

负责：
1. 加载配置
2. 初始化所有服务（依赖注入）
3. 页面路由
"""

import os
import sys
import streamlit as st

# 确保项目根目录在 Python 路径中
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

os.chdir(project_root)


def init_session_state():
    """初始化 Streamlit session state 中的所有服务。"""
    if "initialized" not in st.session_state:
        from app.config import load_config
        from app.database.connection import init_db, create_session_factory
        from app.database.repository import DocumentRepository, ChunkRepository, QAHistoryRepository
        from app.services.embedding_service import EmbeddingService
        from app.search.retriever import ChromaRetriever
        from app.llm.ollama_provider import OllamaLLMProvider
        from app.services.document_service import DocumentService
        from app.services.search_service import SearchService

        # 加载配置
        config = load_config("config.yaml")

        # 初始化数据库
        init_db(config.app.data_dir)

        # 创建 repository
        session_factory = create_session_factory(config.app.data_dir)
        doc_repo = DocumentRepository(session_factory)
        chunk_repo = ChunkRepository(session_factory)
        qa_repo = QAHistoryRepository(session_factory)

        # 创建服务
        embedding_service = EmbeddingService(config.embeddings)
        llm_provider = OllamaLLMProvider(config.llm)

        retriever = ChromaRetriever(
            persist_directory=config.vector_store.persist_directory,
            collection_name=config.vector_store.collection_name,
            embedding_fn=embedding_service.embed_text,
        )

        document_service = DocumentService(
            doc_repo=doc_repo,
            chunk_repo=chunk_repo,
            embedding_service=embedding_service,
            retriever=retriever,
            config=config,
        )

        search_service = SearchService(
            retriever=retriever,
            embedding_service=embedding_service,
            doc_repo=doc_repo,
            llm_provider=llm_provider,
            qa_repo=qa_repo,
        )

        # 存入 session state
        st.session_state.config = config
        st.session_state.document_service = document_service
        st.session_state.search_service = search_service
        st.session_state.embedding_service = embedding_service
        st.session_state.llm_provider = llm_provider
        st.session_state.initialized = True


def main():
    """主函数：页面路由。"""
    # 页面配置
    st.set_page_config(
        page_title="本地知识库",
        page_icon="📚",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # 初始化服务
    init_session_state()

    # 侧边栏导航
    from app.ui.components.sidebar import render_sidebar
    page = render_sidebar()

    # 页面路由
    if page == "🏠 首页":
        from app.ui.pages.home import render_home
        render_home()
    elif page == "📄 文档管理":
        from app.ui.pages.documents import render_documents
        render_documents()
    elif page == "🔍 语义搜索":
        from app.ui.pages.search import render_search
        render_search()
    elif page == "💬 智能问答":
        from app.ui.pages.qa import render_qa
        render_qa()
    elif page == "⚙️ 设置":
        from app.ui.pages.settings import render_settings
        render_settings()


if __name__ == "__main__":
    main()
