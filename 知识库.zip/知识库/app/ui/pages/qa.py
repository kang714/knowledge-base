"""RAG 智能问答页面"""

import streamlit as st


def render_qa():
    """渲染 RAG 问答页面。"""
    st.title("💬 智能问答")

    search_service = st.session_state.search_service
    config = st.session_state.config

    # 侧边设置
    with st.sidebar:
        st.markdown("### 问答设置")
        qa_top_k = st.slider("检索上下文数", 1, 20, config.app.qa_default_top_k)
        use_stream = st.checkbox("流式输出", value=True)

        # 限定范围
        doc_service = st.session_state.document_service
        docs_result = doc_service.list_documents(page_size=1000)
        doc_options = {d["id"]: d["title"] for d in docs_result["items"]}
        selected_docs = st.multiselect(
            "限定文档范围",
            options=list(doc_options.keys()),
            format_func=lambda x: doc_options.get(x, x),
        )

    # 聊天历史
    if "qa_messages" not in st.session_state:
        st.session_state.qa_messages = []

    # 显示历史消息
    for msg in st.session_state.qa_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("sources"):
                with st.expander("📚 参考来源"):
                    for s in msg["sources"]:
                        st.caption(f"**{s['filename']}** (相关度: {int(s['score']*100)}%)")
                        st.text(s["content"][:300] + "..." if len(s["content"]) > 300 else s["content"])

    # 输入区
    question = st.chat_input("基于知识库提问...")

    if question:
        # 添加用户消息
        st.session_state.qa_messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        # 生成回答
        with st.chat_message("assistant"):
            filter_ids = selected_docs if selected_docs else None

            if use_stream:
                # 流式输出
                placeholder = st.empty()
                full_response = ""
                sources = []

                for chunk_data in search_service.answer_question_stream(
                    question, top_k=qa_top_k, filter_doc_ids=filter_ids
                ):
                    if chunk_data.get("sources"):
                        sources = chunk_data["sources"]
                    if not chunk_data.get("done"):
                        full_response += chunk_data["chunk"]
                        placeholder.markdown(full_response + "▌")

                placeholder.markdown(full_response)

                # 显示来源
                if sources:
                    with st.expander("📚 参考来源"):
                        for s in sources:
                            st.caption(f"**{s['filename']}** (相关度: {int(s['score']*100)}%)")
                            st.text(s["content"][:300] + "..." if len(s["content"]) > 300 else s["content"])

                st.session_state.qa_messages.append({
                    "role": "assistant",
                    "content": full_response,
                    "sources": sources,
                })
            else:
                # 非流式输出
                with st.spinner("思考中..."):
                    result = search_service.answer_question(
                        question, top_k=qa_top_k, filter_doc_ids=filter_ids
                    )
                st.markdown(result["answer"])

                if result.get("sources"):
                    with st.expander("📚 参考来源"):
                        for s in result["sources"]:
                            st.caption(f"**{s['filename']}** (相关度: {int(s['score']*100)}%)")
                            st.text(s["content"][:300] + "..." if len(s["content"]) > 300 else s["content"])

                st.session_state.qa_messages.append({
                    "role": "assistant",
                    "content": result["answer"],
                    "sources": result.get("sources", []),
                })

    # 清空对话按钮
    if st.session_state.qa_messages:
        if st.sidebar.button("🗑️ 清空对话", use_container_width=True):
            st.session_state.qa_messages = []
            st.rerun()

    # 问答历史
    with st.sidebar:
        st.markdown("---")
        st.markdown("### 📝 问答历史")
        try:
            history = search_service.get_qa_history(limit=10)
            for entry in history:
                with st.expander(
                    f"Q: {entry['question'][:40]}...",
                ):
                    st.caption(f"时间: {entry['created_at'][:19] if entry.get('created_at') else '未知'}")
                    st.markdown(f"**问**: {entry['question']}")
                    st.markdown(f"**答**: {entry['answer'][:300]}...")
                    st.caption(f"模型: {entry['model_used']}")
        except Exception:
            st.caption("暂无历史记录")
