"""首页 - 仪表盘"""

import streamlit as st


def render_home():
    """渲染首页仪表盘。"""
    st.title("🏠 知识库仪表盘")

    doc_service = st.session_state.document_service

    # 统计卡片
    try:
        stats = doc_service.get_stats()
    except Exception:
        stats = {}

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("📄 文档总数", stats.get("total_docs", 0))
    with col2:
        st.metric("✅ 已就绪", stats.get("ready_docs", 0))
    with col3:
        st.metric("🧩 向量总数", stats.get("vector_count", 0))
    with col4:
        total_mb = (stats.get("total_size_bytes", 0) or 0) / 1024 / 1024
        st.metric("💾 存储大小", f"{total_mb:.1f} MB")

    # 错误文档提醒
    error_count = stats.get("error_docs", 0)
    if error_count > 0:
        st.warning(f"⚠️ {error_count} 个文档处理失败，请到文档管理页面查看详情。")

    st.markdown("---")

    # Ollama 状态
    st.subheader("🔌 服务状态")
    col1, col2 = st.columns(2)

    with col1:
        if "embedding_service" in st.session_state:
            try:
                ollama_status = st.session_state.embedding_service.check_ollama_status()
                if ollama_status["status"] == "running":
                    st.success(f"✅ Ollama 运行中 - 可用模型: {len(ollama_status.get('models', []))} 个")
                else:
                    st.error("❌ Ollama 未运行 - 请执行 `ollama serve` 启动服务")
            except Exception as e:
                st.error(f"❌ Ollama 状态检查失败: {e}")

    with col2:
        if "embedding_service" in st.session_state:
            try:
                provider = st.session_state.embedding_service.get_provider_name()
                st.info(f"🧠 嵌入提供者: {provider}")
            except Exception:
                st.warning("⚠️ 嵌入服务未就绪")

    # 快速搜索
    st.markdown("---")
    st.subheader("🔍 快速搜索")
    quick_query = st.text_input("输入关键词搜索知识库", key="home_search", placeholder="输入搜索内容...")
    if quick_query:
        if st.button("搜索", key="home_search_btn"):
            st.session_state.nav_page = "🔍 语义搜索"
            st.session_state.search_query = quick_query
            st.rerun()

    # 最近文档
    st.markdown("---")
    st.subheader("📋 最近文档")
    try:
        recent = doc_service.doc_repo.get_recent_docs(5)
        if recent:
            for doc in recent:
                d = doc.to_dict()
                status_emoji = {"ready": "✅", "processing": "⏳", "uploaded": "📤", "error": "❌"}
                emoji = status_emoji.get(d["status"], "❓")
                with st.expander(f"{emoji} {d['title']} ({d['file_type']})"):
                    st.write(f"**文件名**: {d['filename']}")
                    st.write(f"**大小**: {d['file_size'] / 1024:.1f} KB")
                    st.write(f"**状态**: {d['status']}")
                    st.write(f"**分块数**: {d['chunk_count']}")
                    st.write(f"**上传时间**: {d['created_at'][:19] if d['created_at'] else '未知'}")
        else:
            st.info("还没有文档，去「📄 文档管理」上传第一个文档吧！")
    except Exception as e:
        st.warning(f"加载最近文档失败: {e}")
