"""语义搜索页面"""

import streamlit as st


def render_search():
    """渲染语义搜索页面。"""
    st.title("🔍 语义搜索")

    search_service = st.session_state.search_service
    config = st.session_state.config

    # 搜索区域
    col1, col2 = st.columns([4, 1])
    with col1:
        # 如果有从首页传来的查询，预填充
        default_query = st.session_state.pop("search_query", "")
        query = st.text_input(
            "输入搜索内容",
            value=default_query,
            placeholder="输入关键词或问题，系统将进行语义搜索...",
            label_visibility="collapsed",
        )
    with col2:
        top_k = st.number_input(
            "结果数",
            min_value=1,
            max_value=50,
            value=config.app.search_default_top_k,
            label_visibility="collapsed",
        )

    # 高级选项
    with st.expander("高级选项"):
        doc_service = st.session_state.document_service
        docs_result = doc_service.list_documents(page_size=1000)
        doc_options = {d["id"]: d["title"] for d in docs_result["items"]}
        selected_docs = st.multiselect(
            "限定搜索范围（留空 = 全部）",
            options=list(doc_options.keys()),
            format_func=lambda x: doc_options.get(x, x),
        )

    if query:
        with st.spinner("搜索中..."):
            filter_ids = selected_docs if selected_docs else None
            results = search_service.search(query, top_k=top_k, filter_doc_ids=filter_ids)

        if results:
            st.success(f"找到 {len(results)} 条相关结果")

            for i, r in enumerate(results):
                with st.container(border=True):
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"**📄 {r['filename']}** （块 #{r['chunk_index'] + 1}）")
                    with col2:
                        # 相似度进度条
                        score_pct = int(r["score"] * 100)
                        st.progress(r["score"], text=f"相关度 {score_pct}%")

                    st.markdown(r["content"][:800] + ("..." if len(r["content"]) > 800 else ""))

                    if st.button(f"📖 查看完整内容", key=f"expand_{i}"):
                        st.text_area(
                            "完整内容",
                            value=r["content"],
                            height=200,
                            key=f"full_{i}",
                            label_visibility="collapsed",
                        )
        else:
            st.warning("未找到相关结果。请尝试其他关键词，或确认知识库中已有文档。")
    else:
        # 空白状态
        st.info("👆 输入搜索关键词开始搜索。系统会使用语义匹配找到最相关的内容。")

        # 快速统计
        try:
            stats = st.session_state.document_service.get_stats()
            if stats["vector_count"] == 0:
                st.warning("⚠️ 知识库中还没有索引数据。请先到「文档管理」页面上传文档。")
        except Exception:
            pass
