"""文档管理页面 - 上传、查看、编辑、删除文档"""

import os
import streamlit as st
from app.ingestion.parser import get_supported_types


def render_documents():
    """渲染文档管理页面。"""
    st.title("📄 文档管理")

    doc_service = st.session_state.document_service
    config = st.session_state.config

    # Tab 切换
    tab1, tab2 = st.tabs(["📤 上传文档", "📋 文档列表"])

    # ---- 上传 Tab ----
    with tab1:
        st.subheader("上传新文档")

        supported_types = get_supported_types()
        type_labels = ", ".join(f".{t}" for t in supported_types)
        st.caption(f"支持的格式: {type_labels}（最大 {config.app.max_file_size_mb}MB）")

        uploaded_files = st.file_uploader(
            "选择文件",
            type=supported_types,
            accept_multiple_files=True,
            label_visibility="collapsed",
        )

        if uploaded_files:
            if st.button("🚀 开始上传并处理", type="primary", use_container_width=True):
                for file in uploaded_files:
                    with st.status(f"处理中: {file.name}...", expanded=True) as status:
                        try:
                            st.write("正在解析文件...")
                            result = doc_service.create_document(file)

                            if result.get("status") == "error":
                                status.update(
                                    label=f"❌ 失败: {file.name}",
                                    state="error",
                                    expanded=False,
                                )
                                st.error(f"错误: {result.get('error_message', '未知错误')}")
                            else:
                                status.update(
                                    label=f"✅ 完成: {file.name}",
                                    state="complete",
                                    expanded=False,
                                )
                                st.success(
                                    f"成功！分块数: {result.get('chunk_count', 0)}, "
                                    f"字符数: {result.get('char_count', 0)}"
                                )
                        except Exception as e:
                            status.update(
                                label=f"❌ 失败: {file.name}",
                                state="error",
                                expanded=False,
                            )
                            st.error(str(e))

                st.rerun()

    # ---- 列表 Tab ----
    with tab2:
        st.subheader("文档列表")

        # 筛选器
        col1, col2, col3 = st.columns([2, 1, 1])
        with col1:
            search_term = st.text_input("搜索文档", placeholder="按文件名/标题搜索")
        with col2:
            status_filter = st.selectbox(
                "状态", ["全部", "ready", "uploaded", "processing", "error"],
                format_func=lambda x: {"全部": "全部", "ready": "✅ 就绪", "uploaded": "📤 已上传", "processing": "⏳ 处理中", "error": "❌ 错误"}[x],
            )
        with col3:
            type_filter = st.selectbox(
                "类型", ["全部"] + get_supported_types()
            )

        # 分页
        page = st.number_input("页码", min_value=1, value=1, label_visibility="collapsed") or 1

        # 查询
        status_arg = None if status_filter == "全部" else status_filter
        type_arg = None if type_filter == "全部" else type_filter
        search_arg = search_term if search_term else None

        result = doc_service.list_documents(
            status=status_arg,
            file_type=type_arg,
            search=search_arg,
            page=page,
            page_size=10,
        )

        st.caption(f"共 {result['total']} 个文档，第 {result['page']}/{result['total_pages']} 页")

        if result["items"]:
            for doc in result["items"]:
                _render_document_card(doc, doc_service)
        else:
            st.info("暂无文档，请切换到「上传文档」标签页上传文件。")

        # 分页控制
        col1, col2, col3 = st.columns([1, 1, 1])
        with col1:
            if page > 1:
                if st.button("⬅️ 上一页"):
                    st.session_state.doc_page = page - 1
                    st.rerun()
        with col3:
            if page < result["total_pages"]:
                if st.button("下一页 ➡️"):
                    st.session_state.doc_page = page + 1
                    st.rerun()


def _render_document_card(doc: dict, doc_service):
    """渲染单个文档卡片。"""
    status_emoji = {"ready": "✅", "processing": "⏳", "uploaded": "📤", "error": "❌"}
    emoji = status_emoji.get(doc["status"], "❓")

    with st.expander(
        f"{emoji} {doc['title']}  |  .{doc['file_type']}  |  "
        f"{doc['file_size'] / 1024:.1f}KB  |  {doc['chunk_count']} 块",
    ):
        col1, col2 = st.columns([3, 1])

        with col1:
            # 查看详情
            st.markdown(f"**文件名**: `{doc['filename']}`")
            st.markdown(f"**标题**: {doc['title']}")
            st.markdown(f"**描述**: {doc['description'] or '（无）'}")
            st.markdown(f"**标签**: {', '.join(doc.get('tags', [])) if doc.get('tags') else '（无）'}")
            st.markdown(f"**状态**: {doc['status']}")
            if doc["error_message"]:
                st.error(f"错误: {doc['error_message']}")
            st.markdown(f"**字符数**: {doc['char_count']:,}")
            st.markdown(f"**时间**: {doc['created_at'][:19] if doc['created_at'] else '未知'}")

            # 查看分块内容
            if doc["status"] == "ready" and doc["chunk_count"] > 0:
                if st.button("📖 查看分块", key=f"view_chunks_{doc['id']}"):
                    chunks = doc_service.get_chunks(doc["id"])
                    for i, chunk in enumerate(chunks):
                        with st.container(border=True):
                            st.caption(f"块 #{chunk['chunk_index'] + 1}")
                            st.text(chunk["content"][:500] + ("..." if len(chunk["content"]) > 500 else ""))

        with col2:
            # 操作按钮
            st.markdown("**操作**")

            # 编辑
            if st.button("✏️ 编辑", key=f"edit_{doc['id']}", use_container_width=True):
                st.session_state[f"editing_{doc['id']}"] = True

            # 重新索引
            if doc["status"] in ("ready", "error"):
                if st.button("🔄 重新索引", key=f"reindex_{doc['id']}", use_container_width=True):
                    with st.spinner("重新索引中..."):
                        try:
                            doc_service.reindex_document(doc["id"])
                            st.success("重新索引完成！")
                            st.rerun()
                        except Exception as e:
                            st.error(f"重新索引失败: {e}")

            # 删除
            if st.button("🗑️ 删除", key=f"delete_{doc['id']}", use_container_width=True, type="secondary"):
                st.session_state[f"confirm_delete_{doc['id']}"] = True

        # 编辑对话框
        if st.session_state.get(f"editing_{doc['id']}"):
            st.markdown("---")
            st.markdown("#### 编辑文档")
            new_title = st.text_input("标题", value=doc["title"], key=f"title_{doc['id']}")
            new_desc = st.text_area("描述", value=doc.get("description", ""), key=f"desc_{doc['id']}")
            tags_str = st.text_input(
                "标签（逗号分隔）",
                value=", ".join(doc.get("tags", [])),
                key=f"tags_{doc['id']}",
            )

            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                if st.button("💾 保存", key=f"save_{doc['id']}", use_container_width=True):
                    new_tags = [t.strip() for t in tags_str.split(",") if t.strip()]
                    doc_service.update_document(
                        doc["id"],
                        title=new_title,
                        description=new_desc,
                        tags=new_tags,
                    )
                    st.session_state[f"editing_{doc['id']}"] = False
                    st.rerun()
            with col_btn2:
                if st.button("取消", key=f"cancel_edit_{doc['id']}", use_container_width=True):
                    st.session_state[f"editing_{doc['id']}"] = False
                    st.rerun()

        # 删除确认
        if st.session_state.get(f"confirm_delete_{doc['id']}"):
            st.markdown("---")
            st.warning(f"⚠️ 确定要删除「{doc['title']}」吗？此操作不可撤销！")
            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                if st.button("✅ 确认删除", key=f"confirm_yes_{doc['id']}", use_container_width=True, type="primary"):
                    doc_service.delete_document(doc["id"])
                    st.session_state[f"confirm_delete_{doc['id']}"] = False
                    st.rerun()
            with col_btn2:
                if st.button("❌ 取消", key=f"confirm_no_{doc['id']}", use_container_width=True):
                    st.session_state[f"confirm_delete_{doc['id']}"] = False
                    st.rerun()
