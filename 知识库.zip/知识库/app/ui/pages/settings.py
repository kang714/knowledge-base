"""设置页面 - 查看配置、检查 Ollama 状态、管理模型"""

import streamlit as st
import yaml
import os


def render_settings():
    """渲染设置页面。"""
    st.title("⚙️ 设置")

    config = st.session_state.config

    tab1, tab2, tab3 = st.tabs(["🔌 服务状态", "📋 当前配置", "🛠️ 工具"])

    # ---- 服务状态 Tab ----
    with tab1:
        st.subheader("Ollama 服务状态")

        if st.button("🔄 刷新状态", key="refresh_status"):
            st.rerun()

        embedding_service = st.session_state.embedding_service
        ollama_status = embedding_service.check_ollama_status()

        if ollama_status["status"] == "running":
            st.success("✅ Ollama 服务正在运行")

            st.subheader("已安装的模型")
            models = ollama_status.get("models", [])
            if models:
                for m in models:
                    st.code(m)
            else:
                st.warning("没有找到已安装的模型")

            # 模型检查
            st.subheader("配置检查")
            llm_config = config.llm
            emb_config = config.embeddings

            llm_available = any(
                m == llm_config.model or m.startswith(llm_config.model.split(":")[0])
                for m in models
            )
            emb_available = any(
                m == emb_config.model or m.startswith(emb_config.model.split(":")[0])
                for m in models
            )

            if llm_available:
                st.success(f"✅ LLM 模型可用: {llm_config.model}")
            else:
                st.error(f"❌ LLM 模型未安装: {llm_config.model}")
                st.code(f"ollama pull {llm_config.model}", language="bash")

            if emb_available:
                st.success(f"✅ 嵌入模型可用: {emb_config.model}")
            else:
                st.error(f"❌ 嵌入模型未安装: {emb_config.model}")
                st.code(f"ollama pull {emb_config.model}", language="bash")

        else:
            st.error("❌ Ollama 服务未运行")
            st.markdown("""
            **启动方法：**
            1. 打开终端
            2. 运行 `ollama serve`
            3. 如果未安装 Ollama，请访问 https://ollama.com 下载安装

            **安装模型（Ollama 启动后）：**
            ```bash
            ollama pull qwen2.5:latest        # LLM 模型（推荐）
            ollama pull nomic-embed-text      # 嵌入模型
            ```
            """)

        st.markdown("---")
        st.subheader("嵌入提供者")
        try:
            provider = embedding_service.get_provider_name()
            st.info(f"当前使用: **{provider}**")
        except Exception as e:
            st.error(f"嵌入服务初始化失败: {e}")

    # ---- 当前配置 Tab ----
    with tab2:
        st.subheader("当前配置")

        config_path = "config.yaml"
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                config_text = f.read()
            st.code(config_text, language="yaml")
        else:
            st.warning("config.yaml 未找到")

        st.caption("💡 修改配置请直接编辑项目目录下的 config.yaml 文件，然后重启应用。")

    # ---- 工具 Tab ----
    with tab3:
        st.subheader("🛠️ 维护工具")

        # 重新索引所有文档
        st.markdown("### 重新索引所有文档")
        st.caption("当修改了分块大小或嵌入模型后，需要重建所有文档的索引。")

        if st.button("🔄 重新索引全部文档", type="secondary"):
            doc_service = st.session_state.document_service
            docs, _ = doc_service.doc_repo.list_all(status="ready", page_size=1000)

            if not docs:
                st.info("没有需要重新索引的文档")
            else:
                progress = st.progress(0, text="准备重新索引...")
                success_count = 0
                fail_count = 0

                for i, doc in enumerate(docs):
                    try:
                        progress.progress(
                            (i + 1) / len(docs),
                            text=f"重新索引: {doc.filename} ({i+1}/{len(docs)})",
                        )
                        doc_service.reindex_document(doc.id)
                        success_count += 1
                    except Exception as e:
                        fail_count += 1
                        st.error(f"失败: {doc.filename} - {e}")

                progress.empty()
                st.success(f"完成！成功: {success_count}, 失败: {fail_count}")

        st.markdown("---")

        # 系统信息
        st.markdown("### 系统信息")
        import sys
        st.json({
            "python_version": sys.version,
            "data_directory": os.path.abspath(config.app.data_dir),
            "chroma_directory": os.path.abspath(config.vector_store.persist_directory),
        })

        # 拉取模型
        st.markdown("---")
        st.markdown("### 拉取 Ollama 模型")
        model_to_pull = st.text_input("输入模型名称", placeholder="例如: qwen2.5:latest")
        if st.button("📥 拉取模型"):
            if model_to_pull:
                st.code(f"请在终端运行: ollama pull {model_to_pull}")
            else:
                st.warning("请输入模型名称")
