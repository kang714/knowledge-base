"""侧边栏导航组件"""

import streamlit as st


def render_sidebar():
    """渲染侧边栏：导航菜单和系统状态。"""
    with st.sidebar:
        st.markdown("## 📚 知识库")

        # 导航
        st.markdown("---")
        page = st.radio(
            "导航",
            ["🏠 首页", "📄 文档管理", "🔍 语义搜索", "💬 智能问答", "⚙️ 设置"],
            label_visibility="collapsed",
        )

        # 系统状态
        st.markdown("---")
        st.markdown("### 系统状态")

        if "document_service" in st.session_state:
            try:
                stats = st.session_state.document_service.get_stats()
                st.metric("文档总数", stats.get("total_docs", 0))
                st.metric("向量总数", stats.get("vector_count", 0))
                provider = stats.get("provider", "未知")
                st.caption(f"嵌入: {provider}")
            except Exception:
                st.caption("状态获取中...")

        st.markdown("---")
        st.caption("本地知识库 v1.0")

    return page
