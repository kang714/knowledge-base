"""知识库系统启动入口

用法: python run.py
然后在浏览器打开 http://localhost:8501
"""

import subprocess
import sys
import os

def main():
    # 确保在项目根目录运行
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    print("=" * 60)
    print("  本地知识库系统")
    print("=" * 60)
    print()
    print("正在启动 Streamlit 服务...")
    print("浏览器打开 http://localhost:8501")
    print("按 Ctrl+C 停止服务")
    print()

    subprocess.run([
        sys.executable, "-m", "streamlit", "run",
        os.path.join("app", "main.py"),
        "--server.headless", "true",
    ])

if __name__ == "__main__":
    main()
